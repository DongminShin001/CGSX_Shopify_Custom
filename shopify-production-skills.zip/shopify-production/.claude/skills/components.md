# Skill: Component Patterns

## Component Inventory

### Art Components
```
components/art/
  ArtCard.tsx           # Grid card with hover
  ArtCardSkeleton.tsx   # Loading state
  ArtGrid.tsx           # Masonry/grid layout
  ArtDetail.tsx         # Full product view
  ArtImageGallery.tsx   # Multi-image viewer
  RelatedWorks.tsx      # Horizontal scroll
```

### Cart Components
```
components/cart/
  CartDrawer.tsx        # Slide-in cart panel
  CartLine.tsx          # Single line item
  CartSummary.tsx       # Totals + checkout CTA
  CartToggle.tsx        # Nav icon + badge
  AddToCartButton.tsx   # Smart add button
  CartEmpty.tsx         # Empty state
```

### Layout Components
```
components/layout/
  Header.tsx            # Fixed nav with scroll behavior
  Footer.tsx            # Minimal footer
  PageLayout.tsx        # Header + children + Footer
  MobileMenu.tsx        # Mobile drawer nav
```

### UI Primitives
```
components/ui/
  Button.tsx
  Badge.tsx
  Skeleton.tsx
  Modal.tsx
  Drawer.tsx
  Spinner.tsx
  Divider.tsx
```

## AddToCartButton
```tsx
import { useState } from 'react';
import { useCart } from '@shopify/hydrogen';
import { cn } from '~/lib/utils';

interface AddToCartButtonProps {
  variantId: string;
  available: boolean;
  className?: string;
}

export function AddToCartButton({ variantId, available, className }: AddToCartButtonProps) {
  const { linesAdd } = useCart();
  const [state, setState] = useState<'idle' | 'loading' | 'added'>('idle');

  async function handleAdd() {
    if (!available || state === 'loading') return;
    setState('loading');
    await linesAdd([{ merchandiseId: variantId, quantity: 1 }]);
    setState('added');
    setTimeout(() => setState('idle'), 2500);
  }

  if (!available) {
    return (
      <button
        disabled
        className={cn('w-full py-4 border border-[var(--border-default)] font-body text-xs tracking-[0.25em] uppercase text-[var(--text-muted)] cursor-not-allowed', className)}
      >
        Sold Out
      </button>
    );
  }

  return (
    <button
      onClick={handleAdd}
      disabled={state === 'loading'}
      className={cn(
        'w-full py-4 font-body text-xs tracking-[0.25em] uppercase transition-all duration-300',
        state === 'added'
          ? 'bg-[var(--success)] text-white'
          : 'bg-white text-black hover:bg-[var(--accent-primary)] hover:text-black',
        className
      )}
    >
      {state === 'loading' ? 'Adding...' : state === 'added' ? 'Added ✓' : 'Add to Collection'}
    </button>
  );
}
```

## CartDrawer
```tsx
import { useCart } from '@shopify/hydrogen';
import { cn } from '~/lib/utils';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const { lines, totalQuantity, cost } = useCart();

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          'fixed inset-0 z-40 bg-black transition-opacity duration-500',
          isOpen ? 'opacity-60 pointer-events-auto' : 'opacity-0 pointer-events-none'
        )}
        onClick={onClose}
      />

      {/* Panel */}
      <div
        className={cn(
          'fixed right-0 top-0 h-full w-full max-w-md z-50 bg-[var(--bg-surface)] border-l border-[var(--border-default)] flex flex-col transition-transform duration-500 ease-out',
          isOpen ? 'translate-x-0' : 'translate-x-full'
        )}
      >
        {/* Header */}
        <div className="flex justify-between items-center px-6 py-5 border-b border-[var(--border-default)]">
          <h2 className="font-display text-xl font-light text-[var(--text-primary)]">
            Collection ({totalQuantity})
          </h2>
          <button onClick={onClose} className="text-[var(--text-muted)] hover:text-white transition-colors p-1">
            <span className="sr-only">Close</span>
            ✕
          </button>
        </div>

        {/* Lines */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {lines.nodes.length === 0
            ? <CartEmpty />
            : lines.nodes.map(line => <CartLine key={line.id} line={line} />)
          }
        </div>

        {/* Footer */}
        {lines.nodes.length > 0 && (
          <div className="px-6 py-6 border-t border-[var(--border-default)] space-y-4">
            <div className="flex justify-between items-center">
              <span className="font-body text-xs tracking-[0.15em] uppercase text-[var(--text-muted)]">Total</span>
              <Money data={cost.totalAmount} className="font-mono text-lg text-[var(--text-primary)]" />
            </div>
            <a
              href={checkoutUrl}
              className="block w-full py-4 bg-white text-black text-center font-body text-xs tracking-[0.25em] uppercase hover:bg-[var(--accent-primary)] transition-colors"
            >
              Checkout
            </a>
          </div>
        )}
      </div>
    </>
  );
}
```

## CartToggle
```tsx
export function CartToggle({ onOpen }: { onOpen: () => void }) {
  const { totalQuantity } = useCart();

  return (
    <button
      onClick={onOpen}
      aria-label={`Cart (${totalQuantity} items)`}
      className="relative p-1 text-[var(--text-secondary)] hover:text-white transition-colors"
    >
      <CartIcon className="w-5 h-5" aria-hidden="true" />
      {totalQuantity > 0 && (
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-[var(--accent-primary)] rounded-full flex items-center justify-center font-mono text-[9px] text-black">
          {totalQuantity > 9 ? '9+' : totalQuantity}
        </span>
      )}
    </button>
  );
}
```

## ArtImageGallery
```tsx
// Multi-image viewer for product detail page
export function ArtImageGallery({ images }: { images: ImageFragment[] }) {
  const [selected, setSelected] = useState(0);

  return (
    <div className="flex gap-3 md:gap-4">
      {/* Thumbnails */}
      <div className="flex flex-col gap-2 w-16 md:w-20 shrink-0">
        {images.map((img, i) => (
          <button
            key={img.url}
            onClick={() => setSelected(i)}
            className={cn(
              'relative aspect-square overflow-hidden transition-opacity',
              selected === i ? 'opacity-100 ring-1 ring-[var(--accent-primary)]' : 'opacity-40 hover:opacity-70'
            )}
          >
            <Image data={img} sizes="80px" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>

      {/* Main image */}
      <div className="flex-1 relative overflow-hidden bg-[var(--bg-surface)]">
        <Image
          data={images[selected]}
          className="w-full h-full object-contain"
          loading="eager"
          sizes="(max-width: 768px) 100vw, 60vw"
        />
      </div>
    </div>
  );
}
```

## Empty States
```tsx
export function CartEmpty() {
  return (
    <div className="flex flex-col items-center justify-center h-full py-20 text-center">
      <p className="font-display text-2xl font-light italic text-[var(--text-muted)]">
        Your collection is empty
      </p>
      <p className="font-body text-sm text-[var(--text-muted)] mt-2 mb-8">
        Add pieces that speak to you
      </p>
      <Link
        to="/collections/all"
        className="font-body text-xs tracking-[0.2em] uppercase text-[var(--text-secondary)] border-b border-[var(--border-default)] pb-0.5 hover:text-white hover:border-white transition-colors"
      >
        Browse Works
      </Link>
    </div>
  );
}

export function EmptyCollection() {
  return (
    <div className="flex flex-col items-center justify-center py-40 text-center">
      <p className="font-display text-4xl font-light italic text-[var(--text-muted)]">
        No works available
      </p>
      <p className="font-body text-sm text-[var(--text-muted)] mt-3 mb-10">
        New pieces coming soon
      </p>
      <Link to="/" className="font-body text-xs tracking-[0.2em] uppercase text-white underline underline-offset-4">
        Return home
      </Link>
    </div>
  );
}
```
