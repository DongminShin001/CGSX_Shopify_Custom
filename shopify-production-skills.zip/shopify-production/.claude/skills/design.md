# Skill: Art Gallery Design System

## Design Philosophy
- Art is the hero — UI disappears
- Editorial, luxury, gallery-quality feel
- Dark canvas makes art pop
- Generous whitespace, intentional typography
- Every interaction: deliberate, refined, memorable
- NEVER generic — this is a premium art brand

## Design Direction: Dark Luxury Editorial
Think: high-end gallery in NYC meets editorial magazine.
Not minimalist for minimalism's sake — minimal with purpose.

## Color System
```css
:root {
  /* Canvas */
  --bg-base: #080808;
  --bg-surface: #111111;
  --bg-elevated: #1a1a1a;
  --bg-overlay: #222222;

  /* Text */
  --text-primary: #f0ede8;        /* warm white, not harsh */
  --text-secondary: #9a9490;
  --text-muted: #4a4845;
  --text-accent: #c9b99a;         /* warm gold */

  /* Accent */
  --accent-primary: #c9b99a;      /* warm gold */
  --accent-hover: #ddd0b8;
  --accent-subtle: rgba(201,185,154,0.1);

  /* Borders */
  --border-default: #1e1e1e;
  --border-subtle: #161616;
  --border-accent: rgba(201,185,154,0.3);

  /* Functional */
  --success: #4a7c59;
  --error: #8b3a3a;
}
```

## Typography
```css
/* Display: hero text, product titles, section headers */
--font-display: 'Cormorant Garamond', serif;
/* weights: 300 (light), 400, 600 — use italic for elegance */

/* Body: descriptions, UI text, nav */
--font-body: 'DM Sans', sans-serif;
/* weights: 300, 400, 500 */

/* Mono: prices, dimensions, metadata */
--font-mono: 'DM Mono', monospace;
/* weight: 300, 400 */
```

Google Fonts import:
```html
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&family=DM+Mono:wght@300;400&display=swap" rel="stylesheet">
```

Tailwind config:
```js
fontFamily: {
  display: ['Cormorant Garamond', 'serif'],
  body: ['DM Sans', 'sans-serif'],
  mono: ['DM Mono', 'monospace'],
}
```

## Typography Scale
```tsx
// Hero title
<h1 className="font-display text-6xl md:text-8xl lg:text-[10rem] font-light leading-none tracking-tight">

// Section title
<h2 className="font-display text-4xl md:text-5xl font-light italic">

// Product title
<h3 className="font-display text-2xl md:text-3xl font-light">

// Label / nav
<span className="font-body text-xs tracking-[0.2em] uppercase text-[var(--text-muted)]">

// Price
<span className="font-mono text-sm tracking-wide text-[var(--text-accent)]">

// Body text
<p className="font-body text-base leading-relaxed text-[var(--text-secondary)]">
```

## Layout System
```tsx
// Page wrapper
<div className="min-h-screen bg-[var(--bg-base)]">

// Content container
<div className="max-w-[1600px] mx-auto px-6 md:px-12 lg:px-20">

// Section spacing
<section className="py-24 md:py-32 lg:py-40">

// Grid gaps
gap-3 md:gap-4        // tight art grid
gap-6 md:gap-8        // relaxed grid
gap-12 md:gap-20      // editorial sections
```

## Art Grid Layouts
```tsx
// Masonry (varied heights — best for art)
<div className="columns-1 md:columns-2 lg:columns-3 xl:columns-4 gap-3 md:gap-4">
  {products.map(p => (
    <div key={p.id} className="break-inside-avoid mb-3 md:mb-4">
      <ArtCard product={p} />
    </div>
  ))}
</div>

// Editorial grid (mix sizes)
<div className="grid grid-cols-12 gap-3 md:gap-4">
  <div className="col-span-12 md:col-span-8">  {/* hero piece */}
  <div className="col-span-12 md:col-span-4">  {/* secondary */}
  <div className="col-span-6 md:col-span-4">   {/* small */}
</div>
```

## Art Card Component
```tsx
export function ArtCard({ product, priority = false }: ArtCardProps) {
  const variant = product.variants.nodes[0];
  const available = product.availableForSale;

  return (
    <article className="group relative cursor-pointer">
      {/* Image */}
      <div className="relative overflow-hidden bg-[var(--bg-surface)]">
        <Image
          data={product.featuredImage}
          className="w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
          loading={priority ? 'eager' : 'lazy'}
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-500" />

        {/* Sold out */}
        {!available && (
          <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-sm px-3 py-1">
            <span className="font-body text-[10px] tracking-[0.2em] uppercase text-[var(--text-muted)]">
              Sold
            </span>
          </div>
        )}

        {/* Quick view on hover */}
        <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
          <Link
            to={`/products/${product.handle}`}
            className="block w-full text-center py-2.5 bg-white/10 backdrop-blur-md border border-white/20 font-body text-xs tracking-[0.2em] uppercase text-white hover:bg-white/20 transition-colors"
          >
            View Piece
          </Link>
        </div>
      </div>

      {/* Info */}
      <div className="mt-3 flex justify-between items-start gap-4">
        <div className="min-w-0">
          <Link to={`/products/${product.handle}`}>
            <h3 className="font-display text-lg font-light text-[var(--text-primary)] truncate hover:text-[var(--accent-primary)] transition-colors">
              {product.title}
            </h3>
          </Link>
          <p className="font-body text-xs tracking-[0.15em] uppercase text-[var(--text-muted)] mt-0.5">
            Original
          </p>
        </div>
        <Money
          data={product.priceRange.minVariantPrice}
          className="font-mono text-sm text-[var(--text-accent)] whitespace-nowrap shrink-0"
        />
      </div>
    </article>
  );
}
```

## Hero Section
```tsx
<section className="relative h-screen min-h-[700px] overflow-hidden">
  <Image
    data={heroImage}
    className="absolute inset-0 w-full h-full object-cover"
    loading="eager"
    sizes="100vw"
  />
  {/* Multi-layer gradient for depth */}
  <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/70" />
  <div className="absolute inset-0 bg-gradient-to-r from-black/30 to-transparent" />

  {/* Content */}
  <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16 lg:p-20">
    <div className="max-w-[1600px] mx-auto">
      <p className="font-body text-[10px] tracking-[0.4em] uppercase text-[var(--text-accent)] mb-6">
        New Collection — 2025
      </p>
      <h1 className="font-display text-6xl md:text-8xl lg:text-[9rem] font-light text-white leading-[0.9] mb-8">
        Original<br />
        <em>Works</em>
      </h1>
      <div className="flex items-center gap-8">
        <Link
          to="/collections/all"
          className="group inline-flex items-center gap-3 font-body text-sm tracking-[0.2em] uppercase text-white"
        >
          <span className="border-b border-white/30 pb-0.5 group-hover:border-white transition-colors duration-300">
            Explore Collection
          </span>
          <span className="transform group-hover:translate-x-1 transition-transform duration-300">→</span>
        </Link>
      </div>
    </div>
  </div>
</section>
```

## Navigation
```tsx
// Fixed, minimal, transparent → blur on scroll
<header className={cn(
  "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
  scrolled
    ? "bg-black/80 backdrop-blur-md border-b border-[var(--border-subtle)]"
    : "bg-transparent"
)}>
  <nav className="max-w-[1600px] mx-auto px-6 md:px-12 py-5 flex justify-between items-center">
    <Link to="/" className="font-display text-xl font-light tracking-wide text-white">
      Studio Name
    </Link>
    <div className="hidden md:flex items-center gap-10">
      <Link to="/collections/all" className="font-body text-xs tracking-[0.2em] uppercase text-[var(--text-secondary)] hover:text-white transition-colors">
        Works
      </Link>
      <Link to="/about" className="font-body text-xs tracking-[0.2em] uppercase text-[var(--text-secondary)] hover:text-white transition-colors">
        About
      </Link>
      <CartToggle />
    </div>
  </nav>
</header>
```

## Animations
```css
/* Page fade in */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Stagger children */
.stagger-children > * {
  animation: fadeIn 0.6s ease-out forwards;
  opacity: 0;
}
.stagger-children > *:nth-child(1) { animation-delay: 0ms; }
.stagger-children > *:nth-child(2) { animation-delay: 80ms; }
.stagger-children > *:nth-child(3) { animation-delay: 160ms; }
.stagger-children > *:nth-child(4) { animation-delay: 240ms; }
```

## Product Detail Page Layout
```
Full-width image top (or left 60% / info right 40%)
  Title (display font, large)
  Medium, Year, Dimensions (mono, small, from metafields)
  Price (mono, accent color)
  Add to Collection button (full width)
  Description (body text, generous line height)
  ─────────────────────
  Related Works (horizontal scroll)
```

## Spacing Reference
```
Section vertical: py-24 md:py-32 lg:py-40
Content max-w:   max-w-[1600px] mx-auto
Padding:         px-6 md:px-12 lg:px-20
Card gap:        gap-3 md:gap-4
Section gap:     gap-12 md:gap-20
```
