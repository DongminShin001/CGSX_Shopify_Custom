# Skill: Error Handling

## Route Error Boundaries (Required on Every Route)
```tsx
import { isRouteErrorResponse, useRouteError, Link } from '@remix-run/react';

export function ErrorBoundary() {
  const error = useRouteError();

  if (isRouteErrorResponse(error)) {
    // 404 - Not Found
    if (error.status === 404) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-6">
          <p className="font-body text-xs tracking-[0.3em] uppercase text-[var(--text-muted)] mb-4">
            404
          </p>
          <h1 className="font-display text-5xl font-light text-[var(--text-primary)] mb-4">
            Not Found
          </h1>
          <p className="font-body text-[var(--text-secondary)] mb-10">
            This piece may have sold or moved.
          </p>
          <Link
            to="/collections/all"
            className="font-body text-xs tracking-[0.2em] uppercase text-white border-b border-white/30 pb-0.5 hover:border-white transition-colors"
          >
            Browse Available Works
          </Link>
        </div>
      );
    }
  }

  // Generic error
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-6">
      <h1 className="font-display text-4xl font-light text-[var(--text-primary)] mb-4">
        Something went wrong
      </h1>
      <Link to="/" className="font-body text-xs tracking-[0.2em] uppercase text-[var(--text-secondary)] hover:text-white">
        Return Home
      </Link>
    </div>
  );
}
```

## Cart Error Handling
```tsx
async function handleAddToCart() {
  try {
    const result = await linesAdd([{ merchandiseId: variantId, quantity: 1 }]);
    
    if (result?.userErrors?.length > 0) {
      const errorMessage = result.userErrors[0].message;
      setError(errorMessage);
      return;
    }
    
    setSuccess(true);
  } catch (err) {
    setError('Failed to add to cart. Please try again.');
    console.error('Cart error:', err);
  }
}
```

## Loader Error Handling
```tsx
export async function loader({ params, context }: LoaderFunctionArgs) {
  try {
    const { product } = await context.storefront.query(PRODUCT_QUERY, {
      variables: { handle: params.handle! },
    });

    // Explicit 404 for missing product
    if (!product) {
      throw new Response('Product not found', { status: 404 });
    }

    return json({ product });
  } catch (error) {
    // Re-throw Response errors (404, etc.) as-is
    if (error instanceof Response) throw error;
    
    // Log unexpected errors
    console.error('Loader error:', error);
    throw new Response('Server Error', { status: 500 });
  }
}
```

## API Error States in UI
```tsx
// Always show error state in components
interface AsyncState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

// Error display component
export function ErrorMessage({ message }: { message: string }) {
  return (
    <div className="p-4 border border-[var(--error)] bg-[var(--error)]/10">
      <p className="font-body text-sm text-red-400">{message}</p>
    </div>
  );
}
```

## Network Error Handling
```tsx
// Retry logic for flaky API calls
async function fetchWithRetry<T>(
  fn: () => Promise<T>,
  retries = 3,
  delay = 500
): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    if (retries <= 0) throw err;
    await new Promise(resolve => setTimeout(resolve, delay));
    return fetchWithRetry(fn, retries - 1, delay * 2);
  }
}
```

## Form Validation Errors
```tsx
// Server-side validation via action
export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData();
  const email = formData.get('email');

  if (!email || typeof email !== 'string') {
    return json({ error: 'Email is required' }, { status: 400 });
  }

  // ... rest of action
}

// Display in component
const actionData = useActionData<typeof action>();
{actionData?.error && <ErrorMessage message={actionData.error} />}
```

## Global Error Logging
```tsx
// Log errors but don't expose internals to user
function logError(error: unknown, context: string) {
  console.error(`[${context}]`, error);
  // Add your error monitoring here (Sentry, etc.)
}
```
