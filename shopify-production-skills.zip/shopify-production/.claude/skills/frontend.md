# Skill: Frontend (React + TypeScript + Tailwind)

## TypeScript Rules
- Strict mode always, zero `any`
- Use `unknown` and narrow types
- Import Shopify generated types from graphql/generated
- Type all props explicitly with interfaces above component

```ts
// Good
import type { ProductCardFragment } from '~/graphql/generated';

interface ProductCardProps {
  product: ProductCardFragment;
  priority?: boolean;
  className?: string;
}

// Never
const data: any = response;
```

## Component Structure
```
components/
  art/
    ArtCard/
      index.ts           # export { ArtCard } from './ArtCard'
      ArtCard.tsx
      ArtCard.test.tsx
  cart/
    CartDrawer/
    CartLine/
    CartToggle/
  layout/
    Header/
    Footer/
    PageLayout/
  ui/
    Button/
    Badge/
    Skeleton/
    Modal/
```

## Component Pattern
```tsx
// Named export always
// Interface above component
// Default values in destructuring
// Explicit return type for complex components

interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  disabled?: boolean;
  className?: string;
  children: React.ReactNode;
  onClick?: () => void;
}

export function Button({
  variant = 'primary',
  size = 'md',
  isLoading = false,
  disabled = false,
  className = '',
  children,
  onClick,
}: ButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || isLoading}
      className={cn(buttonVariants[variant], buttonSizes[size], className)}
    >
      {isLoading ? <Spinner /> : children}
    </button>
  );
}
```

## Tailwind Patterns
```tsx
// cn() utility for conditional classes (install clsx + tailwind-merge)
import { cn } from '~/lib/utils';

// Responsive mobile-first
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">

// Dark mode
<div className="bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100">

// Group hover (card interactions)
<div className="group cursor-pointer">
  <img className="transition-transform duration-700 group-hover:scale-105" />
  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
</div>

// Focus visible (accessibility)
<button className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white">

// Never arbitrary values unless truly needed
// Bad:  w-[347px]
// Good: w-full max-w-sm
```

## Hooks Pattern
```tsx
// Custom hooks in app/hooks/
// One concern per hook

export function useAddToCart(variantId: string) {
  const { linesAdd } = useCart();
  const [state, setState] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  async function addToCart() {
    setState('loading');
    try {
      await linesAdd([{ merchandiseId: variantId, quantity: 1 }]);
      setState('success');
      setTimeout(() => setState('idle'), 2000);
    } catch {
      setState('error');
    }
  }

  return { addToCart, state };
}
```

## Remix Patterns
```tsx
// Data loading — always in loader, never in component
export async function loader({ params, context }: LoaderFunctionArgs) {
  return json({ product });
}

// Forms — use Remix Form, not HTML form
import { Form, useActionData, useNavigation } from '@remix-run/react';
const navigation = useNavigation();
const isSubmitting = navigation.state === 'submitting';

// Optimistic UI
const optimisticCart = useOptimisticCart();
```

## Loading States (Always Required)
```tsx
// Every data-driven component needs skeleton
export function ArtCardSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="aspect-[3/4] bg-zinc-800 rounded-sm" />
      <div className="mt-3 space-y-2">
        <div className="h-4 bg-zinc-800 rounded w-3/4" />
        <div className="h-3 bg-zinc-800 rounded w-1/4" />
      </div>
    </div>
  );
}

// Deferred data pattern
import { Await } from '@remix-run/react';
import { Suspense } from 'react';

<Suspense fallback={<RecommendationsSkeleton />}>
  <Await resolve={recommendations}>
    {(data) => <Recommendations products={data} />}
  </Await>
</Suspense>
```

## Error Boundaries
```tsx
// Every route needs this
export function ErrorBoundary() {
  const error = useRouteError();
  
  if (isRouteErrorResponse(error) && error.status === 404) {
    return <NotFound />;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh]">
      <h1 className="font-display text-2xl text-zinc-100">Something went wrong</h1>
      <Link to="/" className="mt-4 text-zinc-400 hover:text-white">
        Return home
      </Link>
    </div>
  );
}
```

## Accessibility Rules
- Semantic HTML always (nav, main, section, article, aside)
- Every `<img>` meaningful alt text
- Icon-only buttons need aria-label
- Focus rings styled not removed
- Keyboard navigable interactions
- Color contrast 4.5:1 minimum

## Utility: cn()
```ts
// app/lib/utils.ts
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```
