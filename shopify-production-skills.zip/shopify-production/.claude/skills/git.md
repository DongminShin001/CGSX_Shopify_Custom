# Skill: Git Conventions

## Commit Format (Conventional Commits)
```
<type>(<scope>): <description>

feat(cart): add optimistic cart line removal
fix(product): handle null featuredImage gracefully
perf(images): add eager loading to hero and first 4 products
style(gallery): increase card hover transition duration to 700ms
refactor(cart): extract CartLine into separate component
test(AddToCart): add sold out state test
chore(deps): update @shopify/hydrogen to 2025.1.0
docs(readme): add environment variable setup guide
```

## Types
```
feat     → new feature
fix      → bug fix
perf     → performance improvement
style    → styling/design change (no logic)
refactor → code restructure (no behavior change)
test     → adding or fixing tests
chore    → dependency updates, config changes
docs     → documentation only
```

## Scopes (use these)
```
cart, product, collection, gallery, nav, footer,
layout, design, seo, perf, api, auth, checkout,
images, typography, animation, mobile
```

## Branch Naming
```
feat/cart-drawer-animation
fix/product-null-image
perf/hero-image-eager-loading
style/gallery-card-hover
```

## PR Title
Same format as commit: `feat(cart): add optimistic removal`

## When to Commit
- After each working feature/fix (not every save)
- Before switching tasks
- After all tests pass
- Never commit broken code to main
