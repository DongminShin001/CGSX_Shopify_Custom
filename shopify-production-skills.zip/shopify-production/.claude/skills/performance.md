# Skill: Performance

## Images (Critical — Art Gallery)
```tsx
// ALWAYS Hydrogen Image component, never <img>
import { Image } from '@shopify/hydrogen';

// Above fold (hero, first 4 products): eager
<Image data={img} loading="eager" fetchpriority="high" sizes="100vw" />

// Below fold: lazy (default)
<Image data={img} sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw" />

// Always prevent layout shift with aspect ratio
<div className="aspect-[3/4] overflow-hidden">
  <Image data={img} className="w-full h-full object-cover" />
</div>

// Use Shopify CDN transforms
const optimizedUrl = `${img.url}&width=800&quality=85&format=webp`;
```

## Data Loading Strategy
```tsx
// Loader pattern: critical = immediate, non-critical = defer
export async function loader({ context }: LoaderFunctionArgs) {
  // Critical — user sees this immediately
  const { collection } = await context.storefront.query(COLLECTION_QUERY, {
    variables: { handle, first: 12 },
    cache: context.storefront.CacheLong(), // 1hr for collections
  });

  // Non-critical — deferred, doesn't block render
  const recommendations = context.storefront.query(RECOMMENDATIONS_QUERY);

  return defer({ collection, recommendations });
}

// Never fetch inside components
// Never useEffect for data fetching
// Always use loader/action
```

## Caching Rules
```ts
CacheLong()    // Collections, static pages → 1hr
CacheShort()   // Products → 5min (prices can change)
CacheNone()    // Cart, account → never cache
CacheCustom({
  maxAge: 60 * 60 * 2,              // 2hrs
  staleWhileRevalidate: 60 * 60 * 24 // serve stale for 24hrs
})
```

## Code Splitting
```tsx
// Heavy components — dynamic import
import { lazy, Suspense } from 'react';
const ArtImageGallery = lazy(() => import('~/components/art/ArtImageGallery'));

// Route-level splitting is automatic in Remix — no extra config
```

## Bundle Optimization
```ts
// Tree-shake — use specific imports
import { clsx } from 'clsx';           // good
import clsx from 'clsx';               // also fine
// Never: import * from 'lodash'       // bad — imports everything

// Use native methods over lodash when simple
const filtered = arr.filter(x => x.available);   // good
const grouped = arr.reduce(...);                   // good
```

## Pagination — Never Fetch All
```tsx
// Always paginate collections
const PRODUCTS_PER_PAGE = 12;

// Cursor-based pagination (Shopify standard)
const { products } = await storefront.query(COLLECTION_QUERY, {
  variables: {
    first: direction === 'next' ? PRODUCTS_PER_PAGE : null,
    last: direction === 'prev' ? PRODUCTS_PER_PAGE : null,
    startCursor: direction === 'prev' ? pageInfo.startCursor : null,
    endCursor: direction === 'next' ? pageInfo.endCursor : null,
  }
});

// Or use Hydrogen's Pagination component
import { Pagination, getPaginationVariables } from '@shopify/hydrogen';
```

## Prefetching
```tsx
// Prefetch product on hover
import { Link } from '@remix-run/react';
<Link to={`/products/${handle}`} prefetch="intent">
  {/* prefetch="intent" = prefetch on hover/focus */}
</Link>

// Prefetch on viewport entry (for below-fold items)
<Link to={href} prefetch="viewport">
```

## Core Web Vitals Targets
- LCP < 2.5s (hero image must load fast — use eager + CDN)
- CLS = 0 (always set aspect ratios on images)
- FID/INP < 100ms (no heavy JS on main thread)
- TTFB < 600ms (Hydrogen edge rendering helps)

## Font Loading
```html
<!-- Preconnect first -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<!-- Then load with display=swap -->
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&family=DM+Sans:wght@300;400&display=swap" rel="stylesheet">
```

## Avoid
- `useEffect` for data fetching
- Fetching inside components (use loaders)
- Missing `sizes` on Image component
- Missing aspect ratio containers (causes CLS)
- Loading all products at once (paginate)
- Synchronous operations in loaders that could be deferred
- Large client-side JS bundles
