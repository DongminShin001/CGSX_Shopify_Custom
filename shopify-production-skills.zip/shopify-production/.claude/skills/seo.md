# Skill: SEO

## Every Route Needs Meta
```tsx
// Remix meta function — required on every route
export const meta: MetaFunction<typeof loader> = ({ data }) => {
  return [
    { title: data?.product?.seo?.title ?? `${data?.product?.title} | Studio Name` },
    { name: 'description', content: data?.product?.seo?.description ?? data?.product?.description?.slice(0, 155) },
    // Open Graph
    { property: 'og:title', content: data?.product?.title },
    { property: 'og:description', content: data?.product?.description?.slice(0, 155) },
    { property: 'og:image', content: data?.product?.featuredImage?.url },
    { property: 'og:type', content: 'product' },
    // Twitter
    { name: 'twitter:card', content: 'summary_large_image' },
    { name: 'twitter:image', content: data?.product?.featuredImage?.url },
  ];
};
```

## Product Structured Data (JSON-LD)
```tsx
// Add to every product page — critical for Google Shopping
export function ProductJsonLd({ product, variant }: ProductJsonLdProps) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.title,
    description: product.description,
    image: product.images.nodes.map(img => img.url),
    offers: {
      '@type': 'Offer',
      price: variant.price.amount,
      priceCurrency: variant.price.currencyCode,
      availability: variant.availableForSale
        ? 'https://schema.org/InStock'
        : 'https://schema.org/OutOfStock',
      url: `https://yourdomain.com/products/${product.handle}`,
      seller: {
        '@type': 'Organization',
        name: 'Studio Name',
      },
    },
    // Art-specific
    creator: {
      '@type': 'Person',
      name: 'Artist Name',
    },
    artMedium: product.metafields?.find(m => m?.key === 'medium')?.value,
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
    />
  );
}
```

## Canonical URLs
```tsx
// Prevent duplicate content
export const meta: MetaFunction = ({ request }) => [
  { tagName: 'link', rel: 'canonical', href: request.url },
];
```

## Sitemap
```tsx
// app/routes/sitemap.xml.ts
export async function loader({ context }: LoaderFunctionArgs) {
  const { products } = await context.storefront.query(ALL_PRODUCTS_QUERY);
  const { collections } = await context.storefront.query(ALL_COLLECTIONS_QUERY);

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://yourdomain.com/</loc><priority>1.0</priority></url>
  ${products.nodes.map(p => `
  <url>
    <loc>https://yourdomain.com/products/${p.handle}</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <priority>0.8</priority>
  </url>`).join('')}
  ${collections.nodes.map(c => `
  <url>
    <loc>https://yourdomain.com/collections/${c.handle}</loc>
    <priority>0.7</priority>
  </url>`).join('')}
</urlset>`;

  return new Response(sitemap, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600',
    },
  });
}
```

## Robots.txt
```tsx
// app/routes/robots.txt.ts
export async function loader() {
  return new Response(
    `User-agent: *\nAllow: /\nDisallow: /cart\nDisallow: /account\nSitemap: https://yourdomain.com/sitemap.xml`,
    { headers: { 'Content-Type': 'text/plain' } }
  );
}
```

## Page-Specific SEO

### Homepage
```tsx
title: 'Studio Name — Original Art'
description: '25 chars max storename + what you sell + location if relevant'
og:type: 'website'
```

### Collection
```tsx
title: `${collection.title} | Studio Name`
description: collection.description || 'Browse original artworks...'
og:type: 'website'
```

### Product
```tsx
title: product.seo.title || `${product.title} — Original Artwork | Studio Name`
description: product.seo.description || product.description.slice(0, 155)
og:type: 'product'
og:image: product.featuredImage.url (min 1200x630px recommended)
```

## Image Alt Text
```tsx
// Always meaningful, never empty, never "image"
// Good: "Abstract oil painting in blues and golds, 24x36 inches"
// Bad: "product image" or "" or "art"
alt={product.featuredImage.altText || `${product.title} — original artwork`}
```
