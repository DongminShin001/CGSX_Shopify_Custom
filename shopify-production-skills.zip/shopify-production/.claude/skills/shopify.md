# Skill: Shopify Storefront

## API Rules
- Storefront API ONLY — never Admin API on frontend
- GraphQL only, no REST
- API version: 2025-01
- All queries/mutations in app/graphql/ folder
- Use Hydrogen's createStorefrontClient always

## GraphQL Fragments (reuse these)

### ProductCard Fragment
```graphql
fragment ProductCard on Product {
  id
  title
  handle
  availableForSale
  featuredImage {
    url
    altText
    width
    height
  }
  priceRange {
    minVariantPrice {
      amount
      currencyCode
    }
  }
  variants(first: 1) {
    nodes {
      id
      availableForSale
    }
  }
}
```

### ProductDetail Fragment
```graphql
fragment ProductDetail on Product {
  id
  title
  handle
  description
  descriptionHtml
  availableForSale
  seo { title description }
  images(first: 10) {
    nodes { url altText width height }
  }
  priceRange {
    minVariantPrice { amount currencyCode }
    maxVariantPrice { amount currencyCode }
  }
  variants(first: 20) {
    nodes {
      id
      title
      availableForSale
      selectedOptions { name value }
      price { amount currencyCode }
      compareAtPrice { amount currencyCode }
    }
  }
  metafields(identifiers: [
    { namespace: "custom", key: "medium" }
    { namespace: "custom", key: "dimensions" }
    { namespace: "custom", key: "year" }
  ]) {
    key
    value
  }
}
```

## Core Queries

### Homepage
```graphql
query Homepage($featuredCount: Int = 6) {
  featuredCollection: collection(handle: "featured") {
    products(first: $featuredCount) {
      nodes { ...ProductCard }
    }
  }
  newArrivals: collection(handle: "new-arrivals") {
    products(first: 4) {
      nodes { ...ProductCard }
    }
  }
}
```

### Collection Page
```graphql
query Collection(
  $handle: String!
  $first: Int
  $last: Int
  $startCursor: String
  $endCursor: String
  $sortKey: ProductCollectionSortKeys
  $reverse: Boolean
) {
  collection(handle: $handle) {
    id
    title
    description
    seo { title description }
    image { url altText }
    products(
      first: $first
      last: $last
      before: $startCursor
      after: $endCursor
      sortKey: $sortKey
      reverse: $reverse
    ) {
      nodes { ...ProductCard }
      pageInfo {
        hasPreviousPage
        hasNextPage
        startCursor
        endCursor
      }
    }
  }
}
```

### Product Page
```graphql
query Product($handle: String!) {
  product(handle: $handle) {
    ...ProductDetail
  }
  recommendations: productRecommendations(productId: $productId) {
    ...ProductCard
  }
}
```

## Cart Mutations
```graphql
mutation CartCreate($input: CartInput!) {
  cartCreate(input: $input) {
    cart {
      id
      checkoutUrl
      totalQuantity
      lines(first: 20) {
        nodes {
          id
          quantity
          merchandise {
            ... on ProductVariant {
              id
              title
              price { amount currencyCode }
              product { title handle featuredImage { url altText } }
            }
          }
        }
      }
      cost {
        totalAmount { amount currencyCode }
        subtotalAmount { amount currencyCode }
      }
    }
    userErrors { field message }
  }
}

mutation CartLinesAdd($cartId: ID!, $lines: [CartLineInput!]!) {
  cartLinesAdd(cartId: $cartId, lines: $lines) {
    cart { id totalQuantity cost { totalAmount { amount currencyCode } } }
    userErrors { field message }
  }
}

mutation CartLinesUpdate($cartId: ID!, $lines: [CartLineUpdateInput!]!) {
  cartLinesUpdate(cartId: $cartId, lines: $lines) {
    cart { id totalQuantity }
    userErrors { field message }
  }
}

mutation CartLinesRemove($cartId: ID!, $lineIds: [ID!]!) {
  cartLinesRemove(cartId: $cartId, lineIds: $lineIds) {
    cart { id totalQuantity }
  }
}
```

## Hydrogen Hooks & Components
```tsx
// Cart
import { useCart } from '@shopify/hydrogen';
const { lines, totalQuantity, checkoutUrl, linesAdd, linesRemove, linesUpdate } = useCart();

// Money — ALWAYS use this, never manual formatting
import { Money } from '@shopify/hydrogen';
<Money data={variant.price} />

// Images — ALWAYS use this, never <img>
import { Image } from '@shopify/hydrogen';
<Image data={product.featuredImage} sizes="(max-width: 768px) 100vw, 50vw" />

// Analytics
import { usePageAnalytics } from '@shopify/hydrogen';
```

## Route Loader Pattern
```tsx
// app/routes/products.$handle.tsx
export async function loader({ params, context }: LoaderFunctionArgs) {
  const { handle } = params;
  
  // Critical data — returned immediately
  const { product } = await context.storefront.query(PRODUCT_QUERY, {
    variables: { handle },
    cache: context.storefront.CacheShort(), // 5 min
  });

  if (!product) throw new Response('Not Found', { status: 404 });

  // Non-critical — deferred
  const recommendations = context.storefront.query(RECOMMENDATIONS_QUERY, {
    variables: { productId: product.id },
  });

  return defer({ product, recommendations });
}
```

## Caching Strategy
```ts
context.storefront.CacheLong()    // Collections: 1hr
context.storefront.CacheShort()   // Products: 5min
context.storefront.CacheNone()    // Cart: never cache
context.storefront.CacheCustom({  // Custom TTL
  maxAge: 60 * 30,               // 30 min
  staleWhileRevalidate: 60 * 60 * 24,
})
```

## Payments
- Shopify handles ALL payment processing
- Never build custom payment UI
- Redirect to cart.checkoutUrl for checkout
- Enable in Shopify Admin → Settings → Payments
- Supported out of box: Shop Pay, Stripe, PayPal, Apple Pay, Google Pay

## Error Handling
```tsx
// Always handle userErrors from mutations
const { cartLinesAdd } = useCart();
const result = await cartLinesAdd([...]);
if (result.userErrors.length > 0) {
  // handle errors
}

// Always handle null product (404)
if (!product) throw new Response('Not Found', { status: 404 });
```
