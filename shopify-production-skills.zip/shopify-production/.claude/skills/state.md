# Skill: State Management

## State Decision Tree
```
Is it server data? → Remix loader/action (not useState)
Is it cart?        → Hydrogen useCart hook
Is it UI state?    → useState (local to component)
Is it shared UI?   → Context (sparingly)
Is it a form?      → Remix Form + useActionData
Is it URL-driven?  → URL search params
```

## Server State — Always Loaders
```tsx
// NEVER fetch in components — use loaders
// Bad:
function ProductPage() {
  const [product, setProduct] = useState(null);
  useEffect(() => {
    fetch('/api/product').then(r => r.json()).then(setProduct);
  }, []);
}

// Good:
export async function loader({ params, context }: LoaderFunctionArgs) {
  const { product } = await context.storefront.query(PRODUCT_QUERY, {
    variables: { handle: params.handle! },
  });
  return json({ product });
}

export default function ProductPage() {
  const { product } = useLoaderData<typeof loader>();
  return <ProductDetail product={product} />;
}
```

## UI State — useState
```tsx
// Local UI state only
const [isCartOpen, setIsCartOpen] = useState(false);
const [selectedImage, setSelectedImage] = useState(0);
const [selectedVariant, setSelectedVariant] = useState(variants[0]);
```

## Cart State — Hydrogen (Built-in)
```tsx
import { useCart, useOptimisticCart } from '@shopify/hydrogen';

// Read cart
const { lines, totalQuantity, cost, checkoutUrl } = useCart();

// Mutate cart
const { linesAdd, linesRemove, linesUpdate } = useCart();

// Optimistic updates (instant UI feedback)
const optimisticCart = useOptimisticCart();
```

## URL State — Search Params
```tsx
// For filters, sort, pagination — URL is the source of truth
import { useSearchParams } from '@remix-run/react';

const [searchParams, setSearchParams] = useSearchParams();
const sort = searchParams.get('sort') ?? 'BEST_SELLING';

function handleSortChange(value: string) {
  setSearchParams(prev => {
    prev.set('sort', value);
    return prev;
  });
}

// URL: /collections/all?sort=PRICE&direction=asc
```

## Shared UI State — Context (Sparingly)
```tsx
// Only for truly global UI: cart drawer, mobile menu, theme
// app/context/ui.tsx
interface UIContextType {
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  isMobileMenuOpen: boolean;
  toggleMobileMenu: () => void;
}

const UIContext = createContext<UIContextType | null>(null);

export function UIProvider({ children }: { children: React.ReactNode }) {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <UIContext.Provider value={{
      isCartOpen,
      openCart: () => setIsCartOpen(true),
      closeCart: () => setIsCartOpen(false),
      isMobileMenuOpen,
      toggleMobileMenu: () => setIsMobileMenuOpen(prev => !prev),
    }}>
      {children}
    </UIContext.Provider>
  );
}

export function useUI() {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error('useUI must be used within UIProvider');
  return ctx;
}
```

## Optimistic UI
```tsx
// Show instant feedback before server confirms
import { useOptimistic } from 'react';

function CartLine({ line }: { line: CartLine }) {
  const { linesRemove } = useCart();
  const [optimisticRemoved, setOptimisticRemoved] = useOptimistic(false);

  async function handleRemove() {
    setOptimisticRemoved(true);
    await linesRemove([line.id]);
  }

  if (optimisticRemoved) return null;

  return (
    <div>
      {/* line content */}
      <button onClick={handleRemove}>Remove</button>
    </div>
  );
}
```

## Form State
```tsx
// Use Remix Form — no useState for form values
import { Form, useNavigation, useActionData } from '@remix-run/react';

export default function ContactForm() {
  const navigation = useNavigation();
  const actionData = useActionData<typeof action>();
  const isSubmitting = navigation.state === 'submitting';

  return (
    <Form method="post">
      <input name="email" type="email" required />
      {actionData?.errors?.email && <p>{actionData.errors.email}</p>}
      <button type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Sending...' : 'Send'}
      </button>
    </Form>
  );
}
```

## Anti-Patterns to Avoid
```tsx
// ❌ Never: useEffect for data fetching
useEffect(() => { fetch(url).then(setData); }, []);

// ❌ Never: useState for server data
const [products, setProducts] = useState([]);

// ❌ Never: Global state for everything (use URL params instead)
// ❌ Never: Redux/Zustand (Remix + Hydrogen handles this)

// ✅ Always: loader for data
// ✅ Always: useCart for cart
// ✅ Always: useSearchParams for filter/sort/pagination
// ✅ Always: useState for local UI only
```
