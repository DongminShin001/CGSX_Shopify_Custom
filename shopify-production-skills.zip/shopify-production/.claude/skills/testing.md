# Skill: Testing

## Stack
- **Unit/Component**: Vitest + @testing-library/react
- **E2E**: Playwright
- **Mocking**: vi.mock(), msw for API mocks

## File Naming
```
ComponentName.tsx       → ComponentName.test.tsx (same folder)
lib/utils.ts            → lib/utils.test.ts
routes/products.$handle → tests/e2e/product.spec.ts
```

## Component Test Pattern
```tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { vi } from 'vitest';
import { AddToCartButton } from './AddToCartButton';

// Mock Hydrogen cart
vi.mock('@shopify/hydrogen', () => ({
  useCart: vi.fn(() => ({
    linesAdd: vi.fn().mockResolvedValue({ userErrors: [] }),
    totalQuantity: 0,
  })),
  Money: ({ data }: any) => <span>{data.amount} {data.currencyCode}</span>,
  Image: ({ data, ...props }: any) => <img src={data.url} alt={data.altText} {...props} />,
}));

describe('AddToCartButton', () => {
  it('shows "Sold Out" when unavailable', () => {
    render(<AddToCartButton variantId="gid://123" available={false} />);
    expect(screen.getByText('Sold Out')).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeDisabled();
  });

  it('adds to cart on click', async () => {
    const mockLinesAdd = vi.fn().mockResolvedValue({ userErrors: [] });
    vi.mocked(useCart).mockReturnValue({ linesAdd: mockLinesAdd } as any);

    render(<AddToCartButton variantId="gid://123" available={true} />);
    fireEvent.click(screen.getByRole('button'));

    await waitFor(() => {
      expect(mockLinesAdd).toHaveBeenCalledWith([{
        merchandiseId: 'gid://123',
        quantity: 1
      }]);
    });
  });

  it('shows "Added ✓" after successful add', async () => {
    render(<AddToCartButton variantId="gid://123" available={true} />);
    fireEvent.click(screen.getByRole('button'));
    await waitFor(() => expect(screen.getByText('Added ✓')).toBeInTheDocument());
  });
});
```

## E2E Test Pattern (Playwright)
```ts
// tests/e2e/purchase-flow.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Purchase Flow', () => {
  test('browse → add to cart → checkout', async ({ page }) => {
    // Browse gallery
    await page.goto('/');
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();

    // Click first product
    const firstProduct = page.locator('article').first();
    const productLink = firstProduct.locator('a').first();
    await productLink.click();

    // Product page
    await expect(page).toHaveURL(/\/products\//);
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();

    // Add to cart
    await page.getByRole('button', { name: /add to collection/i }).click();
    await expect(page.getByText('Added ✓')).toBeVisible();

    // Cart drawer opens
    await expect(page.getByRole('dialog')).toBeVisible();

    // Checkout
    const checkoutBtn = page.getByRole('link', { name: /checkout/i });
    await expect(checkoutBtn).toBeVisible();
  });

  test('sold out product cannot be added', async ({ page }) => {
    // Navigate to a known sold out product (set in test fixtures)
    await page.goto('/products/test-sold-out-piece');
    const addBtn = page.getByRole('button', { name: /sold out/i });
    await expect(addBtn).toBeDisabled();
  });
});
```

## What to Test
```
✅ Component renders correctly
✅ Loading states shown
✅ Error states handled
✅ User interactions (click, hover, form submit)
✅ Sold out logic
✅ Cart add/remove/update
✅ E2E: full purchase flow
✅ E2E: 404 pages
✅ SEO: meta tags present

❌ Don't test: implementation details
❌ Don't test: Shopify's own APIs
❌ Don't test: CSS classes directly
```

## Mock Storefront Data
```ts
// tests/mocks/products.ts
export const mockProduct = {
  id: 'gid://shopify/Product/1',
  title: 'Abstract Study No. 1',
  handle: 'abstract-study-1',
  availableForSale: true,
  featuredImage: {
    url: 'https://cdn.shopify.com/test.jpg',
    altText: 'Abstract painting',
    width: 800,
    height: 1000,
  },
  priceRange: {
    minVariantPrice: { amount: '850.00', currencyCode: 'USD' }
  },
  variants: {
    nodes: [{
      id: 'gid://shopify/ProductVariant/1',
      availableForSale: true,
      price: { amount: '850.00', currencyCode: 'USD' }
    }]
  }
};
```

## Vitest Config
```ts
// vitest.config.ts
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'jsdom',
    setupFiles: ['./tests/setup.ts'],
    globals: true,
  },
});
```
