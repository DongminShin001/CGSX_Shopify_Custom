# Shopify Art Gallery — Production App

## CRITICAL: Skill Protocol (Read First)
Before ANY task, read relevant skills. Never write code without reading skills first.

| Task Type | Skills to Read |
|-----------|---------------|
| New route/page | shopify + frontend + design + seo |
| Component | frontend + design + components |
| API/data | shopify |
| Styling only | design |
| Tests | testing |
| Performance | performance |
| Bug fix | relevant skill only |
| Full feature | ALL skills |

Invoke skills explicitly: "Read .claude/skills/shopify.md then build X"

## Stack
- Framework: Shopify Hydrogen (Remix)
- Language: TypeScript (strict)
- Styling: Tailwind CSS + CSS variables
- API: Shopify Storefront API v2025-01 (GraphQL only)
- Payments: Shopify native (Shop Pay, Stripe, PayPal, Apple/Google Pay)
- Testing: Vitest + Playwright
- Package manager: npm

## Project Structure
```
app/
  components/     # UI components (see components skill)
  routes/         # Remix routes
  lib/            # Utilities, helpers
  graphql/        # All queries/mutations
  styles/         # Global CSS, tokens
  hooks/          # Custom React hooks
public/           # Static assets
.claude/skills/   # All skill files
```

## Commands
```bash
npm run dev          # Dev server
npm run build        # Production build
npm run typecheck    # TS check
npm run lint         # ESLint
npm run test         # Vitest
npm run test:e2e     # Playwright
```

## Environment Variables
```
PUBLIC_STOREFRONT_API_TOKEN=
PUBLIC_STORE_DOMAIN=
PUBLIC_STOREFRONT_API_VERSION=2025-01
SESSION_SECRET=
```

## Hard Rules
- Storefront API only (never Admin API on frontend)
- GraphQL only (no REST)
- No inline styles (Tailwind only)
- No `any` TypeScript
- Every component needs loading + error state
- Every route needs SEO meta tags
- All images via Hydrogen Image component
- All prices via Hydrogen Money component
- Commit messages: conventional commits format

## Subagent Protocol
When spawning subagents for parallel work:
- Each subagent reads relevant skills before coding
- All follow identical conventions — no drift
- Subagents handle: queries, components, routes, tests in parallel
- Main agent assembles and validates
